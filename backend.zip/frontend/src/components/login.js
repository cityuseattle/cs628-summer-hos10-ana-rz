//HOS10A login.js
import React from "react";

const Login = () => {
  return (
    <a href="https://zany-system-jv44w44696vhjjrg-5050.app.github.dev/facebook" 
    className="btn btn-primary">
      Login with Facebook
    </a>
  );
};

export default Login;
